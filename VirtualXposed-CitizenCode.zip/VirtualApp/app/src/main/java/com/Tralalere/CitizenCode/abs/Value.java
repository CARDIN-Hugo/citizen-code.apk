package com.Tralalere.CitizenCode.abs;

/**
 * @author Lody
 */

public class Value<T> {
    public T val;
}
