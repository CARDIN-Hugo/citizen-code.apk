package com.Tralalere.CitizenCode.vs;

import com.Tralalere.CitizenCode.abs.ui.VActivity;

/**
 * @author Lody
 *
 *
 *
 */
public class VSManagerActivity extends VActivity {
}
