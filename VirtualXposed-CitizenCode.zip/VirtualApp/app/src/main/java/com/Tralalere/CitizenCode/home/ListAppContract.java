package com.Tralalere.CitizenCode.home;

import java.util.List;

import com.Tralalere.CitizenCode.abs.BasePresenter;
import com.Tralalere.CitizenCode.abs.BaseView;
import com.Tralalere.CitizenCode.home.models.AppInfo;

/**
 * @author Lody
 * @version 1.0
 */
/*package*/ class ListAppContract {
    interface ListAppView extends BaseView<ListAppPresenter> {

        void startLoading();

        void loadFinish(List<AppInfo> infoList);
    }

    interface ListAppPresenter extends BasePresenter {

    }
}
