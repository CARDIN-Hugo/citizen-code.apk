package com.Tralalere.CitizenCode.abs;

/**
 * @author Lody
 */
public interface BasePresenter {
	void start();
}
