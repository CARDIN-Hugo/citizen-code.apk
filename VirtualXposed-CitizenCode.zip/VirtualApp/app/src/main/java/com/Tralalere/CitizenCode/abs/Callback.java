package com.Tralalere.CitizenCode.abs;

/**
 * @author Lody
 */

public interface Callback<T> {
    void callback(T result);
}
